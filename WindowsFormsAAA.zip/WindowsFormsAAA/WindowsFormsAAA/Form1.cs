﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsAAA
{
    public partial class Form1 : Form
    {
        private int transactionId = 1; // 初始化 Transaction Identifier

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSendRequest_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 port = 502; // Modbus TCP 預設埠
                TcpClient client = new TcpClient("127.0.0.1", port);

                Byte[] transactionIdBytes = BitConverter.GetBytes((short)transactionId);
                transactionId++;
                Array.Reverse(transactionIdBytes); // 大端序需要反轉字節順序

                Byte[] data = new Byte[]
                {
                    transactionIdBytes[0], transactionIdBytes[1], // Transaction Identifier
                    0x00, 0x00, // Protocol Identifier
                    0x00, 0x06, // Length
                    0x01,       // Unit Identifier
                    0x04,       // Function Code
                    0x0B, 0xBD, // Starting Address
                    0x00, 0x05  // Quantity of Registers
                };

                NetworkStream stream = client.GetStream();

                stream.Write(data, 0, data.Length);
                Log("Sent: " + BitConverter.ToString(data));

                data = new Byte[256];
                Int32 bytes = stream.Read(data, 0, data.Length);

                // 顯示接收到的字節數據
                Log("Received: " + BitConverter.ToString(data, 0, bytes));

                if (bytes > 9)
                {
                    // 提取回應中的字元數據
                    char[] receivedChars = new char[data[8]];
                    for (int i = 0; i < receivedChars.Length; i++)
                    {
                        receivedChars[i] = (char)data[9 + i];
                    }

                    // 將字元數據轉換為字串並解析
                    string receivedStr = new string(receivedChars);
                    Log($"Received String: {receivedStr}");

                    // 假設接收的格式為 "xx.yyzz.aa" (cpuUsage + availableMemory)
                    string[] parts = receivedStr.Split(new[] { '.' }, 2);
                    if (parts.Length == 2)
                    {
                        string cpuPart = parts[0] + "." + parts[1].Substring(0, 2);
                        string memoryPart = parts[1].Substring(2);

                        if (float.TryParse(cpuPart, out float cpuUsage) && float.TryParse(memoryPart, out float availableMemory))
                        {
                            Log($"CPU Usage: {cpuUsage}%");
                            Log($"Available Memory: {availableMemory} MB");
                        }
                        else
                        {
                            Log("Failed to parse received data.");
                        }
                    }
                }

                stream.Close();
                client.Close();
            }
            catch (ArgumentNullException ex)
            {
                Log("ArgumentNullException: " + ex.ToString());
            }
            catch (SocketException ex)
            {
                Log("SocketException: " + ex.ToString());
            }
            catch (IOException ex)
            {
                Log("IOException: " + ex.ToString());
            }
        }

      

        private void Log(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new MethodInvoker(delegate
                {
                    txtLog.AppendText(message + Environment.NewLine);
                }));
            }
            else
            {
                txtLog.AppendText(message + Environment.NewLine);
            }
        }

     
    }
}
