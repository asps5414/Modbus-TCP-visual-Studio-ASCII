﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsBBB
{
    public partial class Form1 : Form
    {
        private TcpListener server = null;
        private Thread serverThread = null;
        private PerformanceCounter cpuCounter;
        private PerformanceCounter ramCounter;

        public Form1()
        {
            InitializeComponent();

            cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            ramCounter = new PerformanceCounter("Memory", "Available MBytes");

            // 啟動計時器以定期更新 CPU 和 RAM 使用率
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000; // 每秒更新一次
            timer.Tick += new EventHandler(UpdatePerformanceCounters);
            timer.Start();
        }

        private void btnStartServer_Click(object sender, EventArgs e)
        {
            if (serverThread == null)
            {
                serverThread = new Thread(StartServer);
                serverThread.IsBackground = true;
                serverThread.Start();
                Log("Server started...");
            }
        }

        private void StartServer()
        {
            try
            {
                Int32 port = 502; // Modbus TCP 預設埠
                IPAddress localAddr = IPAddress.Parse("127.0.0.1");

                server = new TcpListener(localAddr, port);
                server.Start();

                Byte[] bytes = new Byte[256];

                while (true)
                {
                    TcpClient client = server.AcceptTcpClient();
                    NetworkStream stream = client.GetStream();

                    try
                    {
                        int i;
                        while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
                        {
                            // 直接處理字節數組，不轉換為字符串
                            byte[] receivedData = new byte[i];
                            Array.Copy(bytes, 0, receivedData, 0, i);
                            Log("Received: " + BitConverter.ToString(receivedData));

                            // 讀取當前的 CPU 和 RAM 使用率
                            float cpuUsage = cpuCounter.NextValue();
                            float availableMemory = ramCounter.NextValue();

                            // 將 CPU 和 RAM 使用率轉換為字串
                            string cpuUsageStr = cpuUsage.ToString("F2"); // 格式化為兩位小數
                            string availableMemoryStr = availableMemory.ToString(); // 格式化為兩位小數

                            // 將字串轉換為字元數組
                            char[] cpuUsageChars = cpuUsageStr.ToCharArray();
                            char[] availableMemoryChars = availableMemoryStr.ToCharArray();

                            // 構造回應封包，包含 CPU 和 RAM 使用率
                            int totalLength = 9 + cpuUsageChars.Length + availableMemoryChars.Length;
                            byte[] response = new byte[totalLength];

                            // 複製請求中的 Transaction Identifier, Protocol Identifier, Length, Unit Identifier, Function Code
                            Array.Copy(receivedData, 0, response, 0, 8);

                            // 設置 Byte Count
                            response[8] = (byte)(cpuUsageChars.Length + availableMemoryChars.Length);
                            response[5] = (byte)(cpuUsageChars.Length + availableMemoryChars.Length + 3);

                            // 複製字元數組到回應封包
                            for (int j = 0; j < cpuUsageChars.Length; j++)
                            {
                                                                   
                                response[9 + j] = (byte)cpuUsageChars[j];
                                                              
                            }
                            for (int j = 0; j < availableMemoryChars.Length; j++)
                            {
                                response[9 + cpuUsageChars.Length + j] = (byte)availableMemoryChars[j];
                              
                            }
                           
                            stream.Write(response, 0, response.Length);
                            Log("Sent: " + BitConverter.ToString(response));
                        }
                    }
                    catch (IOException ioEx)
                    {
                        Log("IOException: " + ioEx.Message);
                    }
                    finally
                    {
                        client.Close();
                    }
                }
            }
            catch (SocketException e)
            {
                Log("SocketException: " + e.ToString());
            }
            finally
            {
                server.Stop();
            }
        }
        private void UpdatePerformanceCounters(object sender, EventArgs e)
        {
            float cpuUsage = cpuCounter.NextValue();
            float availableMemory = ramCounter.NextValue();
            float totalMemory = GetTotalMemoryInMB();
            float usedMemory = totalMemory - availableMemory;

            string message = string.Format("CPU Usage: {0:0.0}%\r\nUsed Memory: {1:0.0} MB\r\nAvailable Memory: {2:0.0} MB",
                                           cpuUsage, usedMemory, availableMemory);

            if (textBox1.InvokeRequired)
            {
                textBox1.Invoke(new MethodInvoker(delegate
                {
                    textBox1.Text = message;
                }));
            }
            else
            {
                textBox1.Text = message;
            }
        }

        // 獲取總物理記憶體大小
        private float GetTotalMemoryInMB()
        {
            var totalRamCounter = new PerformanceCounter("Memory", "Committed Bytes");
            return totalRamCounter.NextValue() / (1024 * 1024); // 將字節轉換為 MB
        }

        private void Log(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new MethodInvoker(delegate
                {
                    txtLog.AppendText(message + Environment.NewLine);
                }));
            }
            else
            {
                txtLog.AppendText(message + Environment.NewLine);
            }
        }
    }
}
